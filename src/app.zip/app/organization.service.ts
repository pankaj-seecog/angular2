import { Injectable } from '@angular/core';

@Injectable()
export class OrganizationService {

  constructor() { }

}
