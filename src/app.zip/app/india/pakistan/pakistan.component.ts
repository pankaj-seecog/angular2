import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pakistan',
  templateUrl: './pakistan.component.html',
  styleUrls: ['./pakistan.component.css']
})
export class PakistanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
