import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctors',
  templateUrl: './doctors.component.html',
  styleUrls: ['./doctors.component.css']
})
export class DoctorsComponent implements OnInit {

  private doctor : any = {};
  private doctors : any[] = [];
    constructor(private doc : DoctorService) { }

    ngOnInit() {
      this.doc.list().subscribe(
        (res : Response)=>{
        let records = res.json();
        console.log(records)

  this.doctors = Object.keys(records).map(function(key){
  return {key : key,data : records[key]};
  })

        },
        (error)=>{
          console.log('Error is ')
          console.log(error)
        }
        )
    }
    savedoctor(){
  this.doc.save(this.doctor).subscribe(
  (res : Response)=>{
  console.log('Data gets saved')
  console.log(res)
  },
  ()=>{}
  )
    }

}
