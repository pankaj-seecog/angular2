
export class LtaService {

  methodlta(bs) {
    var lta= (10*bs)/100;
    return (lta);
  }

}
