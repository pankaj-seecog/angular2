
export class HraService {

  getHra(bs) {
    var hra= (11*bs)/100;
    return (hra);
  }

}
