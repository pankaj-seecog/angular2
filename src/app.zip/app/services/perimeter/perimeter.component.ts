import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perimeter',
  templateUrl: './perimeter.component.html',
  styleUrls: ['./perimeter.component.css']
})
export class PerimeterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
