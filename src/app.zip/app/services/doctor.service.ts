import { Injectable } from '@angular/core';
import { Http } from '@angular/http/src/http';

@Injectable()
export class DoctorService {

  constructor(private x : Http) { }

  save(doctor : any){
return this.x.post('https://doctors-a8e58.firebaseio.com/doctors.json',doctor);
  }

  list(){
    return this.x.get('https://doctors-a8e58.firebaseio.com/doctors.json');
      }

}
