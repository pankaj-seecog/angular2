
export class DaService {
methodda(bs) {
  var da= (7*bs)/100;
  return (da);
}

}
