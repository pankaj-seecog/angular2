
export class TaService {

  methodta(bs) {
    var ta= (9*bs)/100;
    return (ta);
  }

}
