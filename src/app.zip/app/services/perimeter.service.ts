import { getDefaultService } from "selenium-webdriver/chrome";


export class PerimeterService {

  semiperi(a,b,c){
return (a+b+c)/2.0;
  }

}

