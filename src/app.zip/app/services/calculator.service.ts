
export class CalculatorService{

  add(a,b){
    return(a+b)
  }
subtract(a,b){
  return (a-b)
}
}
